#ifndef GRAFO_H
#define GRAFO_H
#include <vector>

using namespace std;

class Grafo
{
    public:
        Grafo();
        virtual ~Grafo();

    protected:

    private:
};

#endif // GRAFO_H
